
function cargarPagina(){
alert ("Me estoy cargando");
}

function clickPagina (){
alert ("has hecho click");
}